#!/usr/bin/env python3
"""
Sistema Tapatan Robótico - Arquivo Principal
Jogo tradicional filipino implementado com braço robótico UR
"""

import sys
import io
import argparse
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Configurar caminhos do projeto
from utils.configuracao_projeto import configurar_caminho_projeto
configurar_caminho_projeto()

from services.game_orchestrator import GameOrchestrator
from utils.looger_config import configurar_logger

class TapatanMain:
    """Classe principal para execução do sistema Tapatan Robótico"""
    
    def __init__(self, modo_simulacao: bool = True):
        self.logger = configurar_logger()
        self.orchestrator = GameOrchestrator()
        self.modo_simulacao = modo_simulacao
        self.executando = False
        
    def inicializar(self) -> bool:
        """Inicializa o sistema completo"""
        try:
            self.logger.info(" Iniciando Sistema Tapatan Robótico")
            self.logger.info(f"Modo: {'Simulação' if self.modo_simulacao else 'Hardware Real'}")
            
            # Inicializar sistema
            sucesso = self.orchestrator.inicializar_sistema(
                usar_simulacao=self.modo_simulacao
            )
            
            if sucesso:
                self.logger.info(" Sistema inicializado com sucesso")
                self.executando = True
                return True
            else:
                self.logger.error(" Falha na inicialização do sistema")
                return False
                
        except Exception as e:
            self.logger.error(f" Erro na inicialização: {e}", exc_info=True)
            return False
    
    def executar_jogo_interativo(self):
        """Executa o jogo em modo interativo via console"""
        if not self.executando:
            print("Sistema não foi inicializado")
            return
        
        print("\n🎮 === TAPATAN ROBÓTICO - MODO INTERATIVO ===")
        print("Comandos disponíveis:")
        print("  's' - Status do sistema")
        print("  'j' - Simular entrada de jogada")
        print("  'i' - Forçar movimento da IA")
        print("  'p' - Pausar jogo")
        print("  'r' - Retomar jogo")
        print("  'q' - Sair")
        print("=" * 50)
        
        try:
            while self.executando:
                comando = input("\n> Digite um comando: ").strip().lower()
                
                if comando == 'q':
                    print("🛑 Saindo...")
                    break
                elif comando == 's':
                    self._mostrar_status()
                elif comando == 'j':
                    self._simular_jogada()
                elif comando == 'i':
                    self._forcar_movimento_ia()
                elif comando == 'p':
                    self._pausar_jogo()
                elif comando == 'r':
                    self._retomar_jogo()
                else:
                    print("❌ Comando inválido")
                    
        except KeyboardInterrupt:
            print("\n\n🛑 Interrompido pelo usuário")
        except Exception as e:
            self.logger.error(f"❌ Erro durante execução: {e}", exc_info=True)
        finally:
            self.finalizar()
    
    def executar_jogo_automatico(self, num_turnos: int = 10):
        """Executa jogo automatizado para testes"""
        if not self.executando:
            print("❌ Sistema não foi inicializado")
            return
        
        print(f"\n🤖 === MODO AUTOMÁTICO - {num_turnos} TURNOS ===")
        
        # Estado inicial simulado (posições das peças)
        estados_teste = [
            [1, 2, 1, 0, 0, 1, 2, 1, 2],  # Estado inicial
            [1, 2, 1, 0, 1, 0, 2, 1, 2],  # Após movimento
            [1, 2, 1, 2, 1, 0, 0, 1, 2],  # Após outro movimento
        ]
        
        for turno in range(min(num_turnos, len(estados_teste))):
            print(f"\n--- Turno {turno + 1} ---")
            
            estado = estados_teste[turno]
            print(f"Simulando detecção: {estado}")
            
            # Processar turno
            resultado = self.orchestrator.processar_turno_completo(estado)
            
            if resultado.get("sucesso"):
                print("✅ Turno processado com sucesso")
                if resultado.get("movimento_ia"):
                    mov = resultado["movimento_ia"]["movimento"]
                    print(f"🤖 IA jogou: {mov[0]} → {mov[1]}")
            else:
                print(f"❌ Erro no turno: {resultado.get('erro', 'Desconhecido')}")
                break
            
            # Verificar se jogo terminou
            if resultado.get("estado_jogo", {}).get("jogo_terminado"):
                vencedor = resultado["estado_jogo"].get("vencedor")
                if vencedor:
                    print(f"🏆 Jogo terminou! Vencedor: {vencedor}")
                else:
                    print("🤝 Jogo terminou em empate!")
                break
            
            time.sleep(1)  # Pausa entre turnos
    
    def _mostrar_status(self):
        """Mostra status completo do sistema"""
        try:
            status = self.orchestrator.obter_status_sistema()
            
            print("\n📊 === STATUS DO SISTEMA ===")
            print(f"Sistema Ativo: {'✅' if status['sistema_ativo'] else '❌'}")
            print(f"Turno em Andamento: {'✅' if status['turno_em_andamento'] else '❌'}")
            
            # Status do robô
            robo = status.get('robo', {})
            print(f"\n🤖 Robô:")
            print(f"  Conectado: {'✅' if robo.get('conectado') else '❌'}")
            print(f"  Coordenadas: {robo.get('coordenadas_definidas', 0)}/9")
            
            # Status do jogo
            jogo = status.get('jogo')
            if jogo:
                print(f"\n🎮 Jogo:")
                print(f"  Fase: {jogo.get('fase', 'N/A').value}")
                print(f"  Jogador Atual: {jogo.get('jogador_atual', 'N/A').name}")
                
                # Mostrar tabuleiro atual
                tabuleiro = jogo.get('tabuleiro', [])
                if tabuleiro:
                    print("\n📋 Tabuleiro:")
                    self._imprimir_tabuleiro(tabuleiro)
            
            print("=" * 30)
            
        except Exception as e:
            print(f"❌ Erro ao obter status: {e}")
    
    def _simular_jogada(self):
        """Simula entrada de uma jogada"""
        try:
            print("\n🎯 Simulando detecção de movimento...")
            
            # Estado exemplo - pode ser personalizado
            estado_exemplo = [1, 2, 1, 0, 1, 0, 2, 1, 2]
            print(f"Estado detectado: {estado_exemplo}")
            
            resultado = self.orchestrator.processar_turno_completo(estado_exemplo)
            
            if resultado.get("sucesso"):
                print("✅ Jogada processada com sucesso")
            else:
                print(f"❌ Erro: {resultado.get('erro', 'Desconhecido')}")
                
        except Exception as e:
            print(f"❌ Erro na simulação: {e}")
    
    def _forcar_movimento_ia(self):
        """Força movimento da IA"""
        try:
            print("\n🤖 Forçando movimento da IA...")
            
            resultado = self.orchestrator.forcar_movimento_ia()
            
            if resultado.get("sucesso"):
                movimento = resultado.get("movimento", {}).get("movimento")
                if movimento:
                    print(f"✅ IA jogou: {movimento[0]} → {movimento[1]}")
                else:
                    print("⚠️ IA não encontrou movimento válido")
            else:
                print(f"❌ Erro: {resultado.get('erro', 'Desconhecido')}")
                
        except Exception as e:
            print(f"❌ Erro ao forçar movimento: {e}")
    
    def _pausar_jogo(self):
        """Pausa o jogo"""
        try:
            sucesso = self.orchestrator.pausar_jogo()
            if sucesso:
                print("⏸️ Jogo pausado")
            else:
                print("❌ Erro ao pausar jogo")
        except Exception as e:
            print(f"❌ Erro: {e}")
    
    def _retomar_jogo(self):
        """Retoma o jogo"""
        try:
            sucesso = self.orchestrator.retomar_jogo()
            if sucesso:
                print("▶️ Jogo retomado")
            else:
                print("❌ Erro ao retomar jogo")
        except Exception as e:
            print(f"❌ Erro: {e}")
    
    def _imprimir_tabuleiro(self, tabuleiro):
        """Imprime representação visual do tabuleiro"""
        simbolos = {0: '.', 1: 'X', 2: 'O'}
        
        if len(tabuleiro) >= 9:
            # Converter enum para valores se necessário
            valores = []
            for peca in tabuleiro[:9]:
                if hasattr(peca, 'value'):
                    valores.append(peca.value)
                else:
                    valores.append(peca)
            
            print(f"    {simbolos[valores[0]]} - {simbolos[valores[1]]} - {simbolos[valores[2]]}")
            print("    | \\ | / |")
            print(f"    {simbolos[valores[3]]} - {simbolos[valores[4]]} - {simbolos[valores[5]]}")
            print("    | / | \\ |")
            print(f"    {simbolos[valores[6]]} - {simbolos[valores[7]]} - {simbolos[valores[8]]}")
    
    def finalizar(self):
        """Finaliza o sistema de forma segura"""
        try:
            self.logger.info(" Finalizando sistema...")
            
            if self.orchestrator:
                self.orchestrator.finalizar_sistema()
            
            self.executando = False
            self.logger.info(" Sistema finalizado")
            
        except Exception as e:
            self.logger.error(f" Erro na finalização: {e}", exc_info=True)

def main():
    """Função principal"""
    parser = argparse.ArgumentParser(description="Sistema Tapatan Robótico")
    parser.add_argument(
        "--modo", 
        choices=['simulacao', 'hardware'], 
        default='simulacao',
        help="Modo de operação (padrão: simulacao)"
    )
    parser.add_argument(
        "--interface", 
        choices=['interativo', 'automatico'], 
        default='interativo',
        help="Tipo de interface (padrão: interativo)"
    )
    parser.add_argument(
        "--turnos", 
        type=int, 
        default=10,
        help="Número de turnos para modo automático (padrão: 10)"
    )
    
    args = parser.parse_args()
    
    # Criar e configurar sistema
    sistema = TapatanMain(modo_simulacao=(args.modo == 'simulacao'))
    
    try:
        # Inicializar
        if not sistema.inicializar():
            print("❌ Falha na inicialização - encerrando")
            return 1
        
        # Executar interface escolhida
        if args.interface == 'interativo':
            sistema.executar_jogo_interativo()
        else:
            sistema.executar_jogo_automatico(args.turnos)
        
        return 0
        
    except Exception as e:
        print(f"❌ Erro crítico: {e}")
        return 1
    finally:
        sistema.finalizar()

if __name__ == "__main__":
    sys.exit(main())