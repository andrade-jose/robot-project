"""
Robotics Project - Tapatan Game Implementation
"""

__version__ = "1.0.0"
