# services/recovery_service.py
import time
import json
import os

from datetime import datetime
from config.config_completa import Jogador, FaseJogo

class RecoveryService:
    """Responsável pela recuperação de erros e persistência de estado"""
    
    def __init__(self, backup_dir: str = "data/backups"):
        self.backup_dir = backup_dir
        self.max_tentativas_movimento = 3
        self.max_tentativas_conexao = 5
        self.tempo_entre_tentativas = 2.0  # segundos
        
        # Criar diretório de backup se não existir
        os.makedirs(self.backup_dir, exist_ok=True)
    
    def salvar_estado_jogo(self, estado_completo: dict) -> bool:
        """
        Salva o estado completo do jogo para recuperação posterior
        
        Args:
            estado_completo: Dict contendo todo o estado do jogo
            
        Returns:
            bool: True se salvou com sucesso
        """
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            arquivo = os.path.join(self.backup_dir, f"estado_jogo_{timestamp}.json")
            
            # Converter enums para valores serializáveis
            estado_serializado = self._serializar_estado(estado_completo)
            
            with open(arquivo, 'w', encoding='utf-8') as f:
                json.dump(estado_serializado, f, indent=2, ensure_ascii=False)
                
            print(f"✅ Estado salvo em: {arquivo}")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao salvar estado: {e}")
            return False
    
    def carregar_ultimo_estado(self) -> dict | None:
        """
        Carrega o último estado salvo do jogo
        
        Returns:
            Dict com o estado ou None se não encontrar
        """
        try:
            # Encontrar o arquivo mais recente
            arquivos = [f for f in os.listdir(self.backup_dir) 
                       if f.startswith("estado_jogo_") and f.endswith(".json")]
            
            if not arquivos:
                print("⚠️ Nenhum estado salvo encontrado")
                return None
                
            arquivo_mais_recente = max(arquivos)
            caminho_completo = os.path.join(self.backup_dir, arquivo_mais_recente)
            
            with open(caminho_completo, 'r', encoding='utf-8') as f:
                estado_serializado = json.load(f)
                
            # Deserializar estado
            estado = self._deserializar_estado(estado_serializado)
            print(f"✅ Estado carregado de: {arquivo_mais_recente}")
            return estado
            
        except Exception as e:
            print(f"❌ Erro ao carregar estado: {e}")
            return None
    
    def tentar_movimento_com_recovery(self, funcao_movimento, *args, **kwargs) -> bool:
        """
        Executa movimento com tentativas de recuperação em caso de falha
        
        Args:
            funcao_movimento: Função que executa o movimento
            *args, **kwargs: Argumentos para a função
            
        Returns:
            bool: True se movimento foi executado com sucesso
        """
        for tentativa in range(1, self.max_tentativas_movimento + 1):
            try:
                print(f"🔄 Tentativa {tentativa}/{self.max_tentativas_movimento}")
                
                resultado = funcao_movimento(*args, **kwargs)
                if resultado:
                    print("✅ Movimento executado com sucesso")
                    return True
                else:
                    print(f"⚠️ Movimento falhou na tentativa {tentativa}")
                    
            except Exception as e:
                print(f"❌ Erro na tentativa {tentativa}: {e}")
                
            # Aguardar antes da próxima tentativa (exceto na última)
            if tentativa < self.max_tentativas_movimento:
                print(f"⏳ Aguardando {self.tempo_entre_tentativas}s antes da próxima tentativa...")
                time.sleep(self.tempo_entre_tentativas)
        
        print("❌ Todas as tentativas de movimento falharam")
        return False
    
    def tentar_reconexao_robo(self, controller) -> bool:
        """
        Tenta reconectar com o robô em caso de perda de conexão
        
        Args:
            controller: Instância do URController
            
        Returns:
            bool: True se reconectou com sucesso
        """
        for tentativa in range(1, self.max_tentativas_conexao + 1):
            try:
                print(f"🔄 Tentativa de reconexão {tentativa}/{self.max_tentativas_conexao}")
                
                # Tentar verificar conexão
                if controller.is_connected():
                    print("✅ Robô já está conectado")
                    return True
                
                # Se não estiver conectado, tentar reconectar
                # (Isso dependeria da implementação específica do URController)
                print("🔧 Tentando reconectar...")
                
                # Aguardar um pouco para a conexão se estabilizar
                time.sleep(1.0)
                
                if controller.is_connected():
                    print("✅ Reconexão bem-sucedida")
                    return True
                    
            except Exception as e:
                print(f"❌ Erro na tentativa de reconexão {tentativa}: {e}")
                
            # Aguardar antes da próxima tentativa
            if tentativa < self.max_tentativas_conexao:
                print(f"⏳ Aguardando {self.tempo_entre_tentativas}s...")
                time.sleep(self.tempo_entre_tentativas)
        
        print("❌ Não foi possível reconectar com o robô")
        return False
    
    def registrar_erro(self, tipo_erro: str, detalhes: str, contexto: dict = None):
        """
        Registra erro em log para análise posterior
        
        Args:
            tipo_erro: Tipo do erro (ex: "movimento", "conexao", "visao")
            detalhes: Descrição detalhada do erro
            contexto: Informações adicionais sobre o contexto
        """
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_entry = {
                "timestamp": timestamp,
                "tipo": tipo_erro,
                "detalhes": detalhes,
                "contexto": contexto or {}
            }
            
            arquivo_log = os.path.join(self.backup_dir, "erros.log")
            
            with open(arquivo_log, 'a', encoding='utf-8') as f:
                f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
                
        except Exception as e:
            print(f"❌ Erro ao registrar log: {e}")
    
    def executar_procedimento_emergencia(self, controller):
        """
        Executa procedimentos de emergência (parar robô, salvar estado, etc.)
        
        Args:
            controller: Instância do URController
        """
        try:
            print("🚨 INICIANDO PROCEDIMENTO DE EMERGÊNCIA")
            
            # 1. Parar robô imediatamente
            if controller and controller.is_connected():
                controller.emergency_stop()
                print("✅ Robô parado")
            
            # 2. Registrar evento de emergência
            self.registrar_erro(
                "emergencia", 
                "Procedimento de emergência ativado",
                {"timestamp": datetime.now().isoformat()}
            )
            
            print("✅ Procedimento de emergência concluído")
            
        except Exception as e:
            print(f"❌ Erro durante procedimento de emergência: {e}")
    
    def _serializar_estado(self, estado: dict) -> dict:
        """Converte enums e outros objetos para valores serializáveis"""
        estado_serializado = {}
        
        for chave, valor in estado.items():
            if isinstance(valor, list):
                # Processar listas (como tabuleiro)
                estado_serializado[chave] = [
                    item.value if hasattr(item, 'value') else item 
                    for item in valor
                ]
            elif hasattr(valor, 'value'):
                # Processar enums
                estado_serializado[chave] = valor.value
            elif hasattr(valor, 'name'):
                # Processar enums com name
                estado_serializado[chave] = valor.name
            else:
                estado_serializado[chave] = valor
                
        return estado_serializado
    
    def _deserializar_estado(self, estado_serializado: dict) -> dict:
        """Converte valores serializados de volta para objetos apropriados"""
        estado = {}
        
        for chave, valor in estado_serializado.items():
            if chave == 'estado_tabuleiro' and isinstance(valor, list):
                # Converter lista de valores para enums Jogador
                estado[chave] = [Jogador(v) for v in valor]
            elif chave == 'fase' and isinstance(valor, (str, int)):
                # Converter fase para enum
                if isinstance(valor, str):
                    estado[chave] = FaseJogo[valor]
                else:
                    estado[chave] = FaseJogo(valor)
            elif chave == 'jogador_atual' and isinstance(valor, str):
                # Converter jogador para enum
                estado[chave] = Jogador[valor]
            else:
                estado[chave] = valor
                
        return estado
    
    def limpar_backups_antigos(self, dias_manter: int = 7):
        """
        Remove backups mais antigos que o número especificado de dias
        
        Args:
            dias_manter: Número de dias de backups para manter
        """
        try:
            import glob
            from datetime import timedelta
            
            limite_tempo = datetime.now() - timedelta(days=dias_manter)
            
            arquivos = glob.glob(os.path.join(self.backup_dir, "estado_jogo_*.json"))
            removidos = 0
            
            for arquivo in arquivos:
                # Extrair timestamp do nome do arquivo
                nome = os.path.basename(arquivo)
                timestamp_str = nome.replace("estado_jogo_", "").replace(".json", "")
                
                try:
                    timestamp_arquivo = datetime.strptime(timestamp_str, "%Y%m%d_%H%M%S")
                    if timestamp_arquivo < limite_tempo:
                        os.remove(arquivo)
                        removidos += 1
                except ValueError:
                    continue  # Ignorar arquivos com formato incorreto
            
            if removidos > 0:
                print(f"✅ Removidos {removidos} backups antigos")
                
        except Exception as e:
            print(f"❌ Erro ao limpar backups: {e}")