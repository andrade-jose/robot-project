# services/game_orchestrator.py - VERSÃO COMPLETA

import time
from services.game_service import GameService
from services.robot_service import RobotService
from services.vision_service import VisionService
from services.recovery_service import RecoveryService
from logic.interfaces import IGameLogic, ITapatanAI, IRobotController, IVisionService
from config.config_completa import Jogador

class GameOrchestrator:
    """Orquestrador que coordena todos os serviços (SRP, DIP)"""
    def __init__(
        self,
        game_service: GameService = None,
        robot_service: RobotService = None,
        vision_service: VisionService = None,
        recovery_service: RecoveryService = None
    ):
        self.game_service = game_service if game_service is not None else GameService()
        self.robot_service = robot_service if robot_service is not None else RobotService()
        self.vision_service = vision_service if vision_service is not None else VisionService()
        self.recovery_service = recovery_service if recovery_service is not None else RecoveryService()
        
        # Estados de controle
        self.jogo_ativo = False
        self.turno_em_andamento = False
        self.ultimo_estado = None
        
    def inicializar_sistema(self, usar_simulacao: bool = True) -> bool:
        """
        Inicializa todo o sistema de jogo
        
        Args:
            usar_simulacao: Se True, usa coordenadas simuladas
            
        Returns:
            bool: True se inicialização foi bem-sucedida
        """  
        try:
            print("🚀 Inicializando sistema Tapatan Robótico...")
            
            # 1. Conectar robô
            if not self.robot_service.conectar_robo():
                print("❌ Falha ao conectar robô")
                return False
                
            # 1.1 Manter posição atual como home
            print("ℹ️ Usando posição atual como posição inicial")
            self.robot_service.ir_para_home()
            
            # 2. Configurar coordenadas
            if usar_simulacao:
                self._aplicar_coordenadas_simuladas()
            else:
                if not self.robot_service.verificar_coordenadas_completas():
                    print("❌ Coordenadas do tabuleiro não estão completas")
                    return False
            
            # 3. Mover robô para home
            if not self.robot_service.ir_para_home():
                print("❌ Falha ao mover para posição home")
                return False
            
            # 4. Inicializar jogo
            self.game_service.reiniciar_jogo()
            
            # 5. Salvar estado inicial
            self._salvar_estado_atual()
            
            self.jogo_ativo = True
            print("✅ Sistema inicializado com sucesso!")
            return True
            
        except Exception as e:
            print(f"❌ Erro na inicialização: {e}")
            self.recovery_service.executar_procedimento_emergencia(
                self.robot_service.controller
            )
            return False
    
    def processar_turno_completo(self, dados_visao: list) -> dict:
        """
        Processa um turno completo do jogo
        
        Args:
            dados_visao: Lista com 9 valores do estado do tabuleiro
            
        Returns:
            Dict com resultado do turno
        """
        if not self.jogo_ativo:
            return {"erro": "Sistema não inicializado"}
        
        if self.turno_em_andamento:
            return {"erro": "Turno já em andamento"}
        
        try:
            self.turno_em_andamento = True
            
            # 1. Processar visão
            print("👁️ Processando dados de visão...")
            estado_visao = self.vision_service.processar_entrada(dados_visao)
            
            # 2. Atualizar estado do jogo
            print("🎮 Atualizando estado do jogo...")
            estado_jogo = self.game_service.atualizar_estado(
                estado_visao['estado_tabuleiro']
            )
            
            # 3. Verificar se jogo terminou
            if estado_jogo['jogo_terminado']:
                resultado = self._processar_fim_jogo(estado_jogo)
                self.turno_em_andamento = False
                return resultado
            
            # 4. Processar turno da IA se for a vez dela
            resultado_movimento = None
            if estado_jogo['jogador_atual'] == 'JOGADOR1':  # IA
                resultado_movimento = self._processar_turno_ia()
            
            # 5. Salvar estado atual
            self._salvar_estado_atual()
            
            # 6. Preparar resultado
            resultado = {
                "sucesso": True,
                "estado_jogo": estado_jogo,
                "movimento_ia": resultado_movimento,
                "proximo_jogador": self.game_service.jogo.jogador_atual.name
            }
            
            self.turno_em_andamento = False
            return resultado
            
        except Exception as e:
            print(f"❌ Erro no turno: {e}")
            self.recovery_service.registrar_erro("turno", str(e), {
                "dados_visao": dados_visao,
                "turno_em_andamento": self.turno_em_andamento
            })
            
            self.turno_em_andamento = False
            return {"erro": f"Falha no processamento: {e}"}
    
    def executar_movimento_jogador(self, origem: int, destino: int) -> dict:
        """
        Executa movimento do jogador humano
        
        Args:
            origem: Posição de origem
            destino: Posição de destino
            
        Returns:
            Dict com resultado do movimento
        """
        try:
            if not self.jogo_ativo:
                return {"erro": "Sistema não inicializado"}
            
            # Verificar se é o turno do jogador humano
            if self.game_service.jogo.jogador_atual != Jogador.JOGADOR2:
                return {"erro": "Não é o turno do jogador humano"}
            
            # Validar movimento
            if not self.game_service.validar_movimento(origem, destino):
                return {"erro": "Movimento inválido"}
            
            # Executar movimento lógico
            sucesso = self.game_service.executar_movimento(origem, destino)
            
            if sucesso:
                estado_jogo = self.game_service.atualizar_estado(
                    self.game_service.jogo.tabuleiro
                )
                self._salvar_estado_atual()
                
                return {
                    "sucesso": True,
                    "estado_jogo": estado_jogo,
                    "proximo_jogador": self.game_service.jogo.jogador_atual.name
                }
            else:
                return {"erro": "Falha ao executar movimento"}
                
        except Exception as e:
            print(f"❌ Erro no movimento do jogador: {e}")
            return {"erro": str(e)}
    
    def forcar_movimento_ia(self) -> dict:
        """
        Força execução de movimento da IA (útil para testes)
        
        Returns:
            Dict com resultado do movimento
        """
        try:
            if not self.jogo_ativo:
                return {"erro": "Sistema não inicializado"}
            
            resultado = self._processar_turno_ia()
            self._salvar_estado_atual()
            
            return {"sucesso": True, "movimento": resultado}
            
        except Exception as e:
            print(f"❌ Erro no movimento forçado da IA: {e}")
            return {"erro": str(e)}
    
    def obter_status_sistema(self) -> dict:
        """
        Retorna status completo do sistema
        
        Returns:
            Dict com informações de status
        """
        return {
            "sistema_ativo": self.jogo_ativo,
            "turno_em_andamento": self.turno_em_andamento,
            "robo": self.robot_service.obter_status_completo(),
            "jogo": self.game_service.obter_estado_completo() if self.jogo_ativo else None,
            "visao": {
                "coordenadas_definidas": self.vision_service.verificar_coordenadas_completas()
            }
        }
    
    def pausar_jogo(self) -> bool:
        """
        Pausa o jogo e move robô para posição segura
        
        Returns:
            bool: True se pausa foi bem-sucedida
        """
        try:
            print("⏸️ Pausando jogo...")
            
            # Parar robô se estiver se movendo
            self.robot_service.parar_robo()
            
            # Mover para home
            self.robot_service.ir_para_home()
            
            # Salvar estado atual
            self._salvar_estado_atual()
            
            self.jogo_ativo = False
            print("✅ Jogo pausado")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao pausar: {e}")
            return False
    
    def retomar_jogo(self) -> bool:
        """
        Retoma jogo a partir do último estado salvo
        
        Returns:
            bool: True se retomada foi bem-sucedida
        """
        try:
            print("▶️ Retomando jogo...")
            
            # Carregar último estado
            estado = self.recovery_service.carregar_ultimo_estado()
            if estado:
                self.game_service.restaurar_estado(estado)
            
            # Verificar conexão do robô
            if not self.robot_service.verificar_conexao():
                if not self.robot_service.conectar_robo():
                    return False
            
            self.jogo_ativo = True
            print("✅ Jogo retomado")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao retomar: {e}")
            return False
    
    def finalizar_sistema(self) -> bool:
        """
        Finaliza o sistema de forma segura
        
        Returns:
            bool: True se finalização foi bem-sucedida
        """
        try:
            print("🛑 Finalizando sistema...")
            
            # Manter robô na posição atual ao finalizar
            if self.robot_service and self.robot_service.controller.is_connected():
                print("ℹ️ Mantendo posição atual do robô")
            
            # Salvar estado final
            if self.jogo_ativo:
                self._salvar_estado_atual()
            
            # Mover robô para home
            self.robot_service.ir_para_home()
            
            # Desconectar robô
            self.robot_service.desconectar_robo()
            
            # Limpar backups antigos
            self.recovery_service.limpar_backups_antigos()
            
            self.jogo_ativo = False
            print("✅ Sistema finalizado")
            return True
            
        except Exception as e:
            print(f"❌ Erro na finalização: {e}")
            return False
    
    def _processar_turno_ia(self) -> dict | None:
        """Processa turno da IA com tentativas de recuperação"""
        try:
            # Obter movimento da IA
            movimento = self.game_service.obter_movimento_ia()
            
            if not movimento:
                print("⚠️ IA não encontrou movimento válido")
                return None
            
            origem, destino = movimento
            
            # Executar movimento lógico primeiro
            sucesso_logico = self.game_service.executar_movimento(origem, destino)
            
            if not sucesso_logico:
                print("❌ Falha no movimento lógico da IA")
                return None
            
            # Executar movimento físico com recovery
            if origem != -1:  # -1 indica colocação de peça
                sucesso_fisico = self.recovery_service.tentar_movimento_com_recovery(
                    self.robot_service.executar_movimento,
                    origem, destino
                )
            else:
                # Para colocação, não há movimento físico necessário
                sucesso_fisico = True
            
            return {
                "movimento": movimento,
                "sucesso_logico": sucesso_logico,
                "sucesso_fisico": sucesso_fisico
            }
            
        except Exception as e:
            print(f"❌ Erro no turno da IA: {e}")
            self.recovery_service.registrar_erro("ia_turno", str(e))
            return None
    
    def _processar_fim_jogo(self, estado_jogo: dict) -> dict:
        """Processa final do jogo"""
        try:
            print("🏁 Jogo terminado!")
            
            vencedor = estado_jogo.get('vencedor')
            if vencedor:
                print(f"🏆 Vencedor: {vencedor}")
            else:
                print("🤝 Empate!")
            
            # Mover robô para home
            self.robot_service.ir_para_home()
            
            # Salvar estado final
            self._salvar_estado_atual()
            
            self.jogo_ativo = False
            
            return {
                "jogo_terminado": True,
                "vencedor": vencedor,
                "estado_final": estado_jogo
            }
            
        except Exception as e:
            print(f"❌ Erro no fim do jogo: {e}")
            return {"erro": str(e)}
    
    def _aplicar_coordenadas_simuladas(self):
        """Aplica coordenadas simuladas para teste"""
        import numpy as np
        
        coords_mock = np.array([
            [0.3, 0.2, 0.01], [0.4, 0.2, 0.01], [0.5, 0.2, 0.01],
            [0.3, 0.1, 0.01], [0.4, 0.1, 0.01], [0.5, 0.1, 0.01],
            [0.3, 0.0, 0.01], [0.4, 0.0, 0.01], [0.5, 0.0, 0.01],
        ])
        
        self.robot_service.definir_coordenadas_array(coords_mock)
        self.vision_service.definir_coordenadas_simuladas(coords_mock)
        print("✅ Coordenadas simuladas aplicadas")
    
    def _salvar_estado_atual(self):
        """Salva estado atual do sistema"""
        try:
            estado_completo = {
                **self.game_service.obter_estado_completo(),
                "sistema_ativo": self.jogo_ativo,
                "timestamp": time.time()
            }
            
            self.recovery_service.salvar_estado_jogo(estado_completo)
            self.ultimo_estado = estado_completo
            
        except Exception as e:
            print(f"⚠️ Erro ao salvar estado: {e}")