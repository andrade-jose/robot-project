# services/robot_service.py - VERSÃO COMPLETA

import numpy as np
import sys
import os

# Adicionar o diretório raiz do projeto ao PYTHONPATH
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.append(project_root)

from control.ur_controller import URController
from logic.interfaces import IRobotController
from stereo_vision.coordinate_transformer import CoordinateTransformer
from config.config_completa import CONFIG

class RobotService:

    """
    Responsável apenas pelo controle do robô (SRP, DIP)
    """
    def __init__(self, controller: IRobotController = None, usar_coordenadas_ficticias=False):
        self.controller = controller if controller is not None else URController(
            robot_ip=CONFIG['robo'].ip,
            speed=CONFIG['robo'].velocidade_padrao,
            acceleration=CONFIG['robo'].aceleracao_padrao
        )
        self.transformer = CoordinateTransformer()
        self.coordenadas_tabuleiro = {}
        pose_atual = self.controller.get_current_pose()
        self.pose_home = pose_atual
        self.altura_segura = CONFIG['robo'].altura_segura
        self.altura_pegar_peca = CONFIG['robo'].altura_pegar
        self.distancia_segura_minima = 0.028  # 2.8 cm em metros
        self.ultimo_erro = None

    def conectar_robo(self) -> bool:
        """
        Estabelece conexão com o robô
        
        Returns:
            bool: True se conectou com sucesso
        """
        try:
            if self.controller.is_connected():
                print("✅ Robô já está conectado")
                return True
            
            # Tentar reconexão se necessário
            print("🔧 Estabelecendo conexão com robô...")
            
            # Verificar conexão após tentativa
            if self.controller.is_connected():
                print("✅ Conexão estabelecida com sucesso")
                return True
            else:
                print("❌ Falha ao conectar com robô")
                return False
                
        except Exception as e:
            print(f"❌ Erro ao conectar: {e}")
            return False
    
    def definir_coordenadas_tabuleiro(self, coordenadas: dict):
        """
        Define as coordenadas físicas de cada posição do tabuleiro
        
        Args:
            coordenadas: Dict mapeando posição (0-8) para [x, y, z]
        """
        if len(coordenadas) != 9:
            raise ValueError("Deve haver exatamente 9 coordenadas")
        
        for pos in range(9):
            if pos not in coordenadas:
                raise ValueError(f"Coordenada para posição {pos} não encontrada")
            
            coords = coordenadas[pos]
            if len(coords) != 3:
                raise ValueError(f"Coordenada {pos} deve ter 3 valores [x,y,z]")
        
        self.coordenadas_tabuleiro = coordenadas.copy()
        print("✅ Coordenadas do tabuleiro definidas")
    
    def definir_coordenadas_array(self, matriz_coordenadas):
        """
        Define coordenadas a partir de array numpy 9x3

        Args:
            matriz_coordenadas: Array 9x3 com coordenadas [x, y, z]
        """
        if matriz_coordenadas.shape != (9, 3):
            raise ValueError("Matriz deve ser 9x3")

        self.coordenadas_tabuleiro = {
            i: matriz_coordenadas[i].tolist()
            for i in range(9)
        }
        print("✅ Coordenadas do tabuleiro definidas diretamente")


    def definir_coordenadas_ficticias(self):
        # Exemplo: Tabuleiro 3x3 com espaçamento 0.1m (10cm), altura fixa 0.05m
        coords = {}
        espacamento = 0.1
        altura = 0.05
        idx = 0
        for linha in range(3):
            for coluna in range(3):
                x = coluna * espacamento
                y = linha * espacamento
                z = altura
                coords[idx] = [x, y, z]
                idx += 1
        self.definir_coordenadas_tabuleiro(coords)
        print("✅ Coordenadas fictícias do tabuleiro definidas")

    
    def _verificar_distancia_segura(self, pose_alvo) -> bool:
        try:
            pose_atual = self.controller.getActualTCPPose()
            if not pose_atual:
                print("[LOG] Não foi possível obter pose atual do robô para verificação de segurança")
                return False
            
            distancia = self.controller.calcular_distancia_flange_antebraco(pose_alvo)
            print(f"[LOG] Verificando distância segura para pose alvo {pose_alvo}")
            print(f"[LOG] Pose atual do robô: {pose_atual}")
            print(f"[LOG] Distância flange-antebraço: {distancia:.4f} m")

            if distancia < self.distancia_segura_minima:
                self.ultimo_erro = {
                    'codigo': 'C403A0',
                    'mensagem': f'Movimento bloqueado: distância de {distancia*100:.1f}cm é menor que o mínimo de {self.distancia_segura_minima*100:.1f}cm'
                }
                return False
            
            return True
        except Exception as e:
            print(f"❌ Erro ao verificar distância de segurança: {e}")
            return False


    def executar_movimento(self, origem: int, destino: int) -> bool:
        """
        Executa movimento físico de uma peça
        
        Args:
            origem: Posição de origem (0-8)
            destino: Posição de destino (0-8)
            
        Returns:
            bool: True se movimento foi executado com sucesso
        """
        try:
            # Verificações básicas
            if not self.controller.is_connected():
                print("❌ Robô não está conectado")
                return False
            
            if origem == destino:
                print("⚠️ Origem e destino são iguais")
                return False
            
            if (origem not in self.coordenadas_tabuleiro or 
                destino not in self.coordenadas_tabuleiro):
                print("❌ Coordenadas não definidas")
                return False
            
            # Obter coordenadas
            coords_origem = self.coordenadas_tabuleiro[origem][:3]
            coords_destino = self.coordenadas_tabuleiro[destino][:3]

            print(f"[LOG] Executando movimento da posição {origem} para {destino}")
            print(f"[LOG] Coordenadas origem: {coords_origem}")
            print(f"[LOG] Coordenadas destino: {coords_destino}")

            pontos_trajetoria = [
                coords_origem,
                [coords_origem[0], coords_origem[1], self.altura_segura],
                [coords_destino[0], coords_destino[1], self.altura_segura],
                coords_destino
            ]

            print(f"[LOG] Pontos da trajetória para verificação: {pontos_trajetoria}")

            for ponto in pontos_trajetoria:
                if not self._verificar_distancia_segura(ponto):
                    print(f"⚠️ Erro de segurança: {self.ultimo_erro['mensagem']}")
                    return False
            
            # Se todas as verificações passaram, executar movimento
            sucesso = self.controller.executar_movimento_peca(
                coords_origem,
                coords_destino,
                self.altura_segura,
                self.altura_pegar_peca
            )
            
            if sucesso:
                print("✅ Movimento físico concluído")
            else:
                print("❌ Falha no movimento físico")
                if self.controller.ultimo_erro_codigo == 'C403A0':
                    print("⚠️ Detectada condição de colisão potencial (C403A0)")
                    print("⚠️ Movimento interrompido para proteção do robô")
                    self.parada_emergencia()
                
            return sucesso
            
        except Exception as e:
            print(f"❌ Erro durante movimento: {e}")
            self.parada_emergencia()
            return False
    
    def ir_para_home(self):
        print(f"🏠 Movendo para posição home dinâmica: {self.pose_home}")
        return self.controller.move_to_pose(self.pose_home)

    def verificar_conexao(self) -> bool:
        """
        Verifica se robô está conectado
        
        Returns:
            bool: True se conectado
        """
        return self.controller.is_connected()
    
    def obter_pose_atual(self) -> list | None:
        """
        Obtém pose atual do robô
        
        Returns:
            Lista [x,y,z,rx,ry,rz] ou None se erro
        """
        try:
            if not self.controller.is_connected():
                return None
            return self.controller.get_current_pose()
        except Exception as e:
            print(f"❌ Erro ao obter pose: {e}")
            return None
    
    def ajustar_velocidade(self, velocidade: float, aceleracao: float) -> bool:
        """
        Ajusta parâmetros de velocidade
        
        Args:
            velocidade: Nova velocidade (0.01 - 0.25)
            aceleracao: Nova aceleração (0.01 - 0.25)
            
        Returns:
            bool: True se ajuste foi aplicado
        """
        try:
            self.controller.set_speed_parameters(velocidade, aceleracao)
            print(f"✅ Velocidade ajustada: {velocidade}, Aceleração: {aceleracao}")
            return True
        except Exception as e:
            print(f"❌ Erro ao ajustar velocidade: {e}")
            return False
    
    def parar_robo(self) -> bool:
        """
        Para o robô imediatamente
        
        Returns:
            bool: True se comando foi enviado
        """
        try:
            self.controller.stop()
            print("⏹️ Robô parado")
            return True
        except Exception as e:
            print(f"❌ Erro ao parar robô: {e}")
            return False
    
    def parada_emergencia(self) -> bool:
        """
        Parada de emergência
        
        Returns:
            bool: True se comando foi enviado
        """
        try:
            self.controller.emergency_stop()
            print("🚨 PARADA DE EMERGÊNCIA ATIVADA")
            return True
        except Exception as e:
            print(f"❌ Erro na parada de emergência: {e}")
            return False
    
    def desconectar_robo(self) -> bool:
        """
        Desconecta do robô
        
        Returns:
            bool: True se desconectou
        """
        try:
            self.controller.disconnect()
            print("🔌 Robô desconectado")
            return True
        except Exception as e:
            print(f"❌ Erro ao desconectar: {e}")
            return False
    
    def calibrar_posicao(self, posicao: int, coordenadas_fisicas: list) -> bool:
        """
        Calibra uma posição específica do tabuleiro
        
        Args:
            posicao: Posição no tabuleiro (0-8)
            coordenadas_fisicas: Coordenadas [x, y, z] medidas
            
        Returns:
            bool: True se calibração foi salva
        """
        try:
            if posicao < 0 or posicao > 8:
                raise ValueError("Posição deve estar entre 0 e 8")
            
            if len(coordenadas_fisicas) != 3:
                raise ValueError("Coordenadas devem ter 3 valores [x,y,z]")
            
            self.coordenadas_tabuleiro[posicao] = coordenadas_fisicas.copy()
            print(f"✅ Posição {posicao} calibrada: {coordenadas_fisicas}")
            return True
            
        except Exception as e:
            print(f"❌ Erro na calibração: {e}")
            return False
    
    def verificar_coordenadas_completas(self) -> bool:
        """
        Verifica se todas as coordenadas foram definidas
        
        Returns:
            bool: True se todas as 9 coordenadas estão definidas
        """
        if len(self.coordenadas_tabuleiro) != 9:
            print(f"❌ Coordenadas incompletas: {len(self.coordenadas_tabuleiro)}/9")
            return False
        
        for i in range(9):
            if i not in self.coordenadas_tabuleiro:
                print(f"❌ Coordenada {i} não definida")
                return False
        
        print("✅ Todas as coordenadas estão definidas")
        return True
    
    def testar_movimento_seguro(self, posicao: int) -> bool:
        """
        Testa movimento para uma posição específica sem pegar peça
        
        Args:
            posicao: Posição a testar (0-8)
            
        Returns:
            bool: True se teste foi bem-sucedido
        """
        try:
            if not self.controller.is_connected():
                print("❌ Robô não conectado")
                return False
            
            if posicao not in self.coordenadas_tabuleiro:
                print(f"❌ Coordenada {posicao} não definida")
                return False
            
            coords = self.coordenadas_tabuleiro[posicao][:3]
            
            # Criar pose de teste (altura segura)
            pose_teste = coords + [0, 0, 0]  # Adicionar orientação
            pose_teste[2] += self.altura_segura
            
            print(f"🧪 Testando movimento para posição {posicao}")
            self.controller.move_to_pose(pose_teste)
            print(f"✅ Teste da posição {posicao} bem-sucedido")
            return True
            
        except Exception as e:
            print(f"❌ Erro no teste: {e}")
            self.parada_emergencia()
            return False
    
    def obter_status_completo(self) -> dict:
        """
        Retorna status completo do robô
        
        Returns:
            Dict com informações de status
        """
        return {
            'conectado': self.verificar_conexao(),
            'pose_atual': self.obter_pose_atual(),
            'coordenadas_definidas': len(self.coordenadas_tabuleiro),
            'coordenadas_completas': self.verificar_coordenadas_completas(),
            'pose_home': self.pose_home,
            'altura_segura': self.altura_segura,
            'altura_pegar': self.altura_pegar_peca
        }