# services/game_service.py - VERSÃO CORRIGIDA

from logic.interfaces import IGameLogic, ITapatanAI
from config.config_completa import Jogador, FaseJogo
from services.json_serializer import JSONSerializerTapatan
from datetime import datetime

class GameService:
    """GameService com correções de lógica e serialização"""
    
    def __init__(self, jogo=None, ia=None):
        from logic.tapatan_logic import TabuleiraTapatan
        from logic.tapatan_ai import TapatanAI
        
        self.jogo = jogo if jogo is not None else TabuleiraTapatan()
        self.ia = ia if ia is not None else TapatanAI(self.jogo)
        self.historico_movimentos = []
    
    def reiniciar_jogo(self) -> bool:
        """
        Reinicia o jogo para o estado inicial.
        MÉTODO ADICIONADO - Era o que estava causando o erro de inicialização.
        """
        try:
            # Resetar o jogo usando o método interno se existir
            if hasattr(self.jogo, 'reiniciar'):
                self.jogo.reiniciar()
            else:
                # Reinicialização manual
                self.jogo.tabuleiro = [Jogador.VAZIO] * 9
                self.jogo.fase = FaseJogo.COLOCACAO
                self.jogo.jogador_atual = Jogador.JOGADOR2  # Humano começa
                self.jogo.pecas_colocadas = {
                    Jogador.JOGADOR1: 0,
                    Jogador.JOGADOR2: 0
                }
            
            # Limpar histórico
            self.historico_movimentos.clear()
            
            print("🔄 Jogo reiniciado com sucesso")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao reiniciar jogo: {e}")
            return False
    
    def obter_estado_jogo(self) -> dict:
        """
        Retorna informações completas sobre o estado atual do jogo.
        MÉTODO ADICIONADO - Compatível com o formato esperado pelo GameOrchestrator.
        """
        try:
            vencedor = None
            if hasattr(self.jogo, 'verificar_vencedor'):
                vencedor = self.jogo.verificar_vencedor()
            
            jogo_terminado = False
            if hasattr(self.jogo, 'jogo_terminado'):
                jogo_terminado = self.jogo.jogo_terminado()
            elif vencedor is not None:
                jogo_terminado = True
            
            return {
                'tabuleiro': [pos.value if hasattr(pos, 'value') else pos for pos in self.jogo.tabuleiro],
                'fase': self.jogo.fase,
                'jogador_atual': self.jogo.jogador_atual,
                'jogo_terminado': jogo_terminado,
                'vencedor': vencedor,
                'empate': False,  # Implementar lógica de empate se necessário
                'pecas_colocadas': getattr(self.jogo, 'pecas_colocadas', {}),
                'historico_size': len(self.historico_movimentos)
            }
            
        except Exception as e:
            print(f"❌ Erro ao obter estado do jogo: {e}")
            return {
                'tabuleiro': [0] * 9,
                'fase': FaseJogo.COLOCACAO,
                'jogador_atual': Jogador.JOGADOR2,
                'jogo_terminado': False,
                'vencedor': None,
                'empate': False,
                'pecas_colocadas': {},
                'historico_size': 0
            }
    
    def validar_estado(self, estado: list) -> bool:
        """
        Valida se o estado do jogo é válido.
        MÉTODO ADICIONADO - Validações robustas de estado.
        """
        try:
            # Verificar se tem exatamente 9 posições
            if len(estado) != 9:
                return False
            
            # Verificar se todos os valores são válidos (0, 1 ou 2)
            if not all(valor in [0, 1, 2] for valor in estado):
                return False
            
            # Contar peças de cada jogador
            pecas_j1 = estado.count(1)
            pecas_j2 = estado.count(2)
            
            # Verificar se não há mais de 3 peças por jogador
            if pecas_j1 > 3 or pecas_j2 > 3:
                return False
            
            # Verificar se a diferença de peças não é maior que 1
            # (indica jogadas alternadas válidas)
            if abs(pecas_j1 - pecas_j2) > 1:
                return False
                
            return True
            
        except Exception as e:
            print(f"❌ Erro na validação: {e}")
            return False
    
    def executar_movimento(self, origem: int, destino: int) -> bool:
        """
        Executa um movimento no tabuleiro com validações.
        MÉTODO ADICIONADO - Execução segura de movimentos.
        """
        try:
            # Salvar estado atual no histórico antes de modificar
            estado_atual = self.obter_estado_completo()
            self.historico_movimentos.append(estado_atual)
            
            # Verificar se o jogo tem o método fazer_movimento
            if hasattr(self.jogo, 'fazer_movimento'):
                sucesso = self.jogo.fazer_movimento(origem, destino)
                if sucesso:
                    print(f"✅ Movimento executado: {origem} → {destino}")
                return sucesso
            else:
                # Implementação manual básica
                if origem == destino:  # Colocação de peça
                    if self.jogo.tabuleiro[destino] == Jogador.VAZIO:
                        self.jogo.tabuleiro[destino] = self.jogo.jogador_atual
                        return True
                else:  # Movimento de peça
                    if (self.jogo.tabuleiro[origem] == self.jogo.jogador_atual and 
                        self.jogo.tabuleiro[destino] == Jogador.VAZIO):
                        self.jogo.tabuleiro[origem] = Jogador.VAZIO
                        self.jogo.tabuleiro[destino] = self.jogo.jogador_atual
                        return True
                return False
                
        except Exception as e:
            print(f"❌ Erro ao executar movimento: {e}")
            return False
    
    def desfazer_ultimo_movimento(self) -> bool:
        """
        Desfaz o último movimento se possível.
        MÉTODO ADICIONADO - Sistema de undo.
        """
        try:
            if not self.historico_movimentos:
                print("⚠️ Não há movimentos para desfazer")
                return False
            
            # Restaurar estado anterior
            estado_anterior = self.historico_movimentos.pop()
            sucesso = self.restaurar_estado(estado_anterior)
            
            if sucesso:
                print("↩️ Último movimento desfeito")
            
            return sucesso
            
        except Exception as e:
            print(f"❌ Erro ao desfazer movimento: {e}")
            return False
    
    def obter_movimento_ia(self, profundidade: int = 3) -> tuple | None:
        """Obtém movimento da IA com lógica corrigida"""
        try:
            if self.jogo.jogo_terminado():
                print("⚠️ Jogo já terminado, sem movimentos disponíveis")
                return None
            
            if self.jogo.jogador_atual != Jogador.JOGADOR1:
                print(f"⚠️ Não é o turno da IA. Turno atual: {self.jogo.jogador_atual.name}")
                return None
            
            # Debug: Imprimir estado atual
            print(f"🔍 Debug - Fase: {self.jogo.fase.value}")
            print(f"🔍 Debug - Peças J1: {self.jogo.pecas_colocadas.get(Jogador.JOGADOR1, 0)}")
            print(f"🔍 Debug - Peças J2: {self.jogo.pecas_colocadas.get(Jogador.JOGADOR2, 0)}")
            print(f"🔍 Debug - Tabuleiro: {[p.value for p in self.jogo.tabuleiro]}")
            
            movimento = None
            
            if self.jogo.fase == FaseJogo.COLOCACAO:
                # Verificar se realmente ainda está na fase de colocação
                pecas_j1 = sum(1 for p in self.jogo.tabuleiro if p == Jogador.JOGADOR1)
                if pecas_j1 >= 3:
                    print("🔄 Forçando mudança para fase de movimento")
                    self.jogo.fase = FaseJogo.MOVIMENTO
                    movimento = self._obter_movimento_minimax(profundidade)
                else:
                    movimento = self._obter_movimento_colocacao()
                    
            elif self.jogo.fase == FaseJogo.MOVIMENTO:
                movimento = self._obter_movimento_minimax(profundidade)
            else:
                print(f"❌ Fase de jogo inválida: {self.jogo.fase}")
                return None
            
            if movimento:
                print(f"✅ IA escolheu movimento: {movimento[0]} → {movimento[1]}")
                return movimento
            else:
                print("⚠️ IA não encontrou movimento válido")
                return None
                
        except Exception as e:
            print(f"❌ Erro ao obter movimento da IA: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _obter_movimento_minimax(self, profundidade: int) -> tuple | None:
        """Obtém movimento usando minimax"""
        try:
            if hasattr(self.ia, 'fazer_jogada_robo_minimax'):
                return self.ia.fazer_jogada_robo_minimax(profundidade)
            else:
                print("❌ Método fazer_jogada_robo_minimax não encontrado")
                return self._obter_movimento_simples()
        except Exception as e:
            print(f"❌ Erro no minimax: {e}")
            return self._obter_movimento_simples()
    
    def _obter_movimento_simples(self) -> tuple | None:
        """Movimento simples como fallback"""
        try:
            movimentos_validos = self.jogo.obter_movimentos_validos(Jogador.JOGADOR1)
            if movimentos_validos:
                return movimentos_validos[0]
            return None
        except Exception as e:
            print(f"❌ Erro no movimento simples: {e}")
            return None
    
    def _obter_movimento_colocacao(self) -> tuple | None:
        """Movimento para fase de colocação corrigido"""
        try:
            posicoes_vazias = self.jogo.obter_posicoes_vazias()
            if not posicoes_vazias:
                return None
            
            # Verificar quantas peças o jogador atual já colocou
            pecas_colocadas = sum(1 for p in self.jogo.tabuleiro if p == self.jogo.jogador_atual)
            
            if pecas_colocadas >= 3:
                print(f"❌ Jogador {self.jogo.jogador_atual.name} já colocou {pecas_colocadas} peças")
                return None
            
            # Priorizar posições estratégicas
            posicoes_priorizadas = [4, 0, 2, 6, 8, 1, 3, 5, 7]
            
            for pos in posicoes_priorizadas:
                if pos in posicoes_vazias:
                    return (pos, pos)  # Para colocação, origem = destino
            
            return (posicoes_vazias[0], posicoes_vazias[0])
            
        except Exception as e:
            print(f"❌ Erro no movimento de colocação: {e}")
            return None
    
    def atualizar_estado(self, estado_tabuleiro: list) -> dict:
        """Atualiza estado com correção da fase"""
        try:
            if len(estado_tabuleiro) != 9:
                raise ValueError("Estado do tabuleiro deve ter 9 posições")

            # Validar estado antes de aplicar
            if not self.validar_estado(estado_tabuleiro):
                raise ValueError("Estado fornecido é inválido")

            # Converter e atualizar tabuleiro
            self.jogo.tabuleiro = [Jogador(val) for val in estado_tabuleiro]
            
            # Contar peças reais no tabuleiro
            pecas_j1 = sum(1 for p in self.jogo.tabuleiro if p == Jogador.JOGADOR1)
            pecas_j2 = sum(1 for p in self.jogo.tabuleiro if p == Jogador.JOGADOR2)
            
            # Atualizar contadores
            self.jogo.pecas_colocadas[Jogador.JOGADOR1] = pecas_j1
            self.jogo.pecas_colocadas[Jogador.JOGADOR2] = pecas_j2
            
            # Determinar fase correta baseada nas peças reais
            if pecas_j1 == 3 and pecas_j2 == 3:
                self.jogo.fase = FaseJogo.MOVIMENTO
            elif pecas_j1 < 3 or pecas_j2 < 3:
                self.jogo.fase = FaseJogo.COLOCACAO
            
            # Verificar vitória
            vencedor = self.jogo.verificar_vencedor()
            if vencedor:
                self.jogo.fase = FaseJogo.JOGO_TERMINADO
            
            print(f"🔍 Estado atualizado - J1: {pecas_j1}, J2: {pecas_j2}, Fase: {self.jogo.fase.value}")
            
            return {
                'estado_tabuleiro': [pos.value for pos in self.jogo.tabuleiro],
                'fase': self.jogo.fase.value,
                'jogador_atual': self.jogo.jogador_atual.name,
                'movimentos_validos': self.jogo.obter_movimentos_validos(),
                'vencedor': vencedor.name if vencedor else None,
                'jogo_terminado': self.jogo.jogo_terminado(),
                'num_pecas_jogador1': pecas_j1,
                'num_pecas_jogador2': pecas_j2
            }
            
        except Exception as e:
            print(f"❌ Erro ao atualizar estado: {e}")
            return {'erro': str(e)}
    
    def salvar_estado_seguro(self, caminho_arquivo: str = None) -> bool:
        """Salva estado usando serializer seguro"""
        try:
            if caminho_arquivo is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                caminho_arquivo = f"data/backups/estado_jogo_{timestamp}.json"
            
            estado = self.obter_estado_completo()
            return JSONSerializerTapatan.salvar_estado_json(estado, caminho_arquivo)
            
        except Exception as e:
            print(f"❌ Erro ao salvar estado: {e}")
            return False
    
    def carregar_estado_seguro(self, caminho_arquivo: str) -> bool:
        """Carrega estado usando deserializer seguro"""
        try:
            estado = JSONSerializerTapatan.carregar_estado_json(caminho_arquivo)
            if estado is None:
                return False
            
            return self.restaurar_estado(estado)
            
        except Exception as e:
            print(f"❌ Erro ao carregar estado: {e}")
            return False
    
    def obter_estado_completo(self) -> dict:
        """Retorna estado completo"""
        return {
            'tabuleiro': self.jogo.tabuleiro.copy(),
            'fase': self.jogo.fase,
            'jogador_atual': self.jogo.jogador_atual,
            'pecas_colocadas': self.jogo.pecas_colocadas.copy(),
            'historico_movimentos': self.historico_movimentos.copy()
        }
    
    def restaurar_estado(self, estado: dict) -> bool:
        """Restaura estado do jogo"""
        try:
            if 'tabuleiro' in estado:
                self.jogo.tabuleiro = estado['tabuleiro']
            if 'fase' in estado:
                if isinstance(estado['fase'], str):
                    fase_map = {
                        'colocacao': FaseJogo.COLOCACAO,
                        'movimento': FaseJogo.MOVIMENTO,
                        'jogo_terminado': FaseJogo.JOGO_TERMINADO
                    }
                    self.jogo.fase = fase_map.get(estado['fase'], FaseJogo.COLOCACAO)
                else:
                    self.jogo.fase = estado['fase']
            
            if 'jogador_atual' in estado:
                self.jogo.jogador_atual = estado['jogador_atual']
            if 'pecas_colocadas' in estado:
                self.jogo.pecas_colocadas = estado['pecas_colocadas']
            if 'historico_movimentos' in estado:
                self.historico_movimentos = estado['historico_movimentos']
            
            print("✅ Estado restaurado com sucesso")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao restaurar estado: {e}")
            return False


# Exemplo de uso das correções
def exemplo_correcoes():
    """Demonstra como usar as correções"""
    # Criar GameService corrigido
    game_service = GameService()
    
    # Simular estado com 6 peças (3 de cada jogador)
    estado_exemplo = [1, 2, 1, 0, 1, 0, 2, 0, 2]  # 3 peças de cada
    print("🧪 Testando correções...")
    
    # Atualizar estado
    resultado = game_service.atualizar_estado(estado_exemplo)
    print(f"Estado: {resultado}")
    
    # Tentar obter movimento da IA
    movimento = game_service.obter_movimento_ia()
    print(f"Movimento IA: {movimento}")
    
    # Salvar estado de forma segura
    sucesso = game_service.salvar_estado_seguro()
    print(f"Salvamento: {sucesso}")

if __name__ == "__main__":
    exemplo_correcoes()