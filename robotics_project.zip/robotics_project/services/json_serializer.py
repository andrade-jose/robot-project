import json
from datetime import datetime
from pathlib import Path
from config.config_completa import Jogador, FaseJogo

class JSONSerializerTapatan:
    """Serializer customizado para objetos do Tapatan"""
    
    @staticmethod
    def default_serializer(obj):
        """Conversor padrão para objetos não serializáveis"""
        if isinstance(obj, Jogador):
            return {
                '__type__': 'Jogador',
                'value': obj.value,
                'name': obj.name
            }
        elif isinstance(obj, FaseJogo):
            return {
                '__type__': 'FaseJogo', 
                'value': obj.value
            }
        elif hasattr(obj, '__dict__'):
            # Para outros objetos, tentar serializar o __dict__
            return {
                '__type__': obj.__class__.__name__,
                '__dict__': obj.__dict__
            }
        else:
            return str(obj)
    
    @staticmethod
    def object_hook(dct):
        """Hook para deserialização de objetos customizados"""
        if '__type__' in dct:
            if dct['__type__'] == 'Jogador':
                return Jogador(dct['value'])
            elif dct['__type__'] == 'FaseJogo':
                return FaseJogo(dct['value'])
        return dct
    
    @staticmethod
    def preparar_para_json(estado: dict) -> dict:
        """Prepara estado para serialização JSON segura"""
        estado_limpo = {}
        
        for chave, valor in estado.items():
            # Converter chave para string se for enum
            if isinstance(chave, (Jogador, FaseJogo)):
                chave_str = f"{chave.__class__.__name__}_{chave.value}"
            else:
                chave_str = str(chave)
            
            # Converter valor
            if isinstance(valor, list):
                valor_limpo = [
                    v.value if isinstance(v, (Jogador, FaseJogo)) else v 
                    for v in valor
                ]
            elif isinstance(valor, dict):
                valor_limpo = {}
                for k, v in valor.items():
                    k_str = f"{k.__class__.__name__}_{k.value}" if isinstance(k, (Jogador, FaseJogo)) else str(k)
                    v_clean = v.value if isinstance(v, (Jogador, FaseJogo)) else v
                    valor_limpo[k_str] = v_clean
            elif isinstance(valor, (Jogador, FaseJogo)):
                valor_limpo = valor.value
            else:
                valor_limpo = valor
            
            estado_limpo[chave_str] = valor_limpo
        
        return estado_limpo
    
    @staticmethod
    def salvar_estado_json(estado: dict, caminho_arquivo: str) -> bool:
        """Salva estado em arquivo JSON de forma segura"""
        try:
            # Preparar estado para JSON
            estado_json = JSONSerializerTapatan.preparar_para_json(estado)
            estado_json['timestamp'] = datetime.now().isoformat()
            
            # Criar diretório se não existir
            Path(caminho_arquivo).parent.mkdir(parents=True, exist_ok=True)
            
            # Salvar arquivo
            with open(caminho_arquivo, 'w', encoding='utf-8') as f:
                json.dump(estado_json, f, indent=2, ensure_ascii=False)
            
            print(f"✅ Estado salvo em: {caminho_arquivo}")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao salvar estado JSON: {e}")
            return False
    
    @staticmethod
    def carregar_estado_json(caminho_arquivo: str) -> dict | None:
        """Carrega estado de arquivo JSON"""
        try:
            if not Path(caminho_arquivo).exists():
                print(f"❌ Arquivo não encontrado: {caminho_arquivo}")
                return None
            
            with open(caminho_arquivo, 'r', encoding='utf-8') as f:
                estado_json = json.load(f)
            
            # Converter de volta para objetos Python
            estado = JSONSerializerTapatan._converter_de_json(estado_json)
            
            print(f"✅ Estado carregado de: {caminho_arquivo}")
            return estado
            
        except Exception as e:
            print(f"❌ Erro ao carregar estado JSON: {e}")
            return None
    
    @staticmethod
    def _converter_de_json(estado_json: dict) -> dict:
        """Converte estado JSON de volta para objetos Python"""
        estado = {}
        
        for chave, valor in estado_json.items():
            if chave == 'timestamp':
                continue
                
            # Converter chave de volta
            if chave.startswith('Jogador_'):
                chave_obj = Jogador(int(chave.split('_')[1]))
            elif chave.startswith('FaseJogo_'):
                chave_obj = chave.split('_')[1]  # Manter como string para facilitar
            else:
                chave_obj = chave
            
            # Converter valor de volta
            if isinstance(valor, list):
                if chave == 'tabuleiro':
                    valor_obj = [Jogador(v) for v in valor]
                else:
                    valor_obj = valor
            elif isinstance(valor, dict):
                valor_obj = {}
                for k, v in valor.items():
                    if k.startswith('Jogador_'):
                        k_obj = Jogador(int(k.split('_')[1]))
                    else:
                        k_obj = k
                    valor_obj[k_obj] = v
            else:
                valor_obj = valor
            
            estado[chave_obj] = valor_obj
        
        return estado