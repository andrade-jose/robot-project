# services/vision_service.py
import numpy as np

from stereo_vision.coordinate_transformer import CoordinateTransformer
from config.config_completa import Jogador
from logic.interfaces import IVisionService

class VisionService:
    """Responsável apenas pelo processamento de visão (SRP, DIP)"""
    def __init__(self, transformer: CoordinateTransformer = None):
        self.transformer = transformer if transformer is not None else CoordinateTransformer()
        self.coordenadas_detectadas = {}
        
    def processar_entrada(self, dados_visao: list) -> dict:
        """
        Processa dados do sistema de visão (classificador ou simulado)
        
        Args:
            dados_visao: Lista com 9 valores representando o estado do tabuleiro
                        0 = vazio, 1 = jogador1, 2 = jogador2
        
        Returns:
            Dict com estado processado do tabuleiro
        """
        if len(dados_visao) != 9:
            raise ValueError("Dados de visão devem ter exatamente 9 valores")
            
        # Converter valores para enum Jogador
        estado_tabuleiro = []
        for valor in dados_visao:
            if valor == 0:
                estado_tabuleiro.append(Jogador.VAZIO)
            elif valor == 1:
                estado_tabuleiro.append(Jogador.JOGADOR1)
            elif valor == 2:
                estado_tabuleiro.append(Jogador.JOGADOR2)
            else:
                raise ValueError(f"Valor inválido na posição: {valor}")
        
        return {
            'estado_tabuleiro': estado_tabuleiro,
            'coordenadas_detectadas': self.coordenadas_detectadas.copy(),
            'timestamp': self._get_timestamp()
        }
    
    def calibrar_coordenadas(self, coordenadas_camera: list, coordenadas_robo: list):
        """
        Calibra a transformação entre coordenadas da câmera e do robô
        
        Args:
            coordenadas_camera: Lista de pontos [x, y, z] da câmera
            coordenadas_robo: Lista de pontos [x, y, z] correspondentes do robô
        """
        if len(coordenadas_camera) != len(coordenadas_robo):
            raise ValueError("Número de pontos da câmera e robô devem ser iguais")
            
        if len(coordenadas_camera) < 3:
            raise ValueError("Mínimo de 3 pontos necessários para calibração")
            
        try:
            self.transformer.set_transformation_from_points(
                coordenadas_camera, coordenadas_robo
            )
            self.transformer.save_transformation()
            print("✅ Calibração de coordenadas concluída")
        except Exception as e:
            print(f"❌ Erro na calibração: {e}")
            raise
    
    def definir_coordenadas_simuladas(self, matriz_coordenadas):
        """
        Define coordenadas simuladas para teste sem câmera
        
        Args:
            matriz_coordenadas: Array 9x3 com coordenadas [x, y, z] de cada posição
        """
        if matriz_coordenadas.shape != (9, 3):
            raise ValueError("Matriz deve ser 9x3 (9 posições, 3 coordenadas cada)")
            
        for i in range(9):
            self.coordenadas_detectadas[i] = matriz_coordenadas[i].tolist()
            
        print("✅ Coordenadas simuladas definidas")
    
    def obter_coordenadas_posicao(self, posicao: int) -> list | None:
        """
        Obtém as coordenadas de uma posição específica do tabuleiro
        
        Args:
            posicao: Posição no tabuleiro (0-8)
            
        Returns:
            Lista [x, y, z] ou None se não encontrada
        """
        return self.coordenadas_detectadas.get(posicao)
    
    def detectar_tabuleiro_stereo(self):
        """
        Placeholder para detecção real com câmera estéreo
        TODO: Implementar quando câmera estiver funcionando
        """
        print("⚠️ Detecção estéreo não implementada - usando coordenadas simuladas")
        return None
    
    def _get_timestamp(self) -> float:
        """Retorna timestamp atual"""
        import time
        return time.time()
    
    def verificar_coordenadas_completas(self) -> bool:
        """Verifica se todas as 9 coordenadas foram definidas"""
        if len(self.coordenadas_detectadas) != 9:
            return False
            
        for i in range(9):
            if i not in self.coordenadas_detectadas:
                return False
                
        return True