from rtde_control import RTDEControlInterface
from rtde_receive import RTDEReceiveInterface  # ✅ Adicionado
import time
from utils.configuracao_projeto import configurar_caminho_projeto

class URController:
    def __init__(self, robot_ip="192.168.15.25", speed=0.1, acceleration=0.1):
        self.robot_ip = robot_ip
        self.speed = speed  # Velocidade reduzida para maior segurança
        self.acceleration = acceleration  # Aceleração reduzida
        self.rtde_c = RTDEControlInterface(self.robot_ip)
        self.rtde_r = RTDEReceiveInterface(self.robot_ip)  # ✅ Instância de leitura

        # Parâmetros de segurança
        self.pause_between_moves = 0.5  # Pausa entre movimentos em segundos
        self.safe_height_offset = 0.1   # Altura segura acima do tabuleiro
        self.min_elbow_tcp_distance = 0.028  # Distância mínima entre cotovelo e TCP (2.8cm)
        self.last_error = None  # Armazena último erro

        # Configurações de movimento
        self.max_joint_change = 0.5  # Máxima mudança permitida nas juntas (radianos)
        self.planning_steps = 10  # Número de passos para planejamento de trajetória

    def is_connected(self):
        return self.rtde_c and self.rtde_c.isConnected()

    def getActualTCPPose(self):
        """Alias para get_current_pose para compatibilidade."""
        return self.get_current_pose()

    def get_current_pose(self):
        """Retorna a pose atual do robô"""
        if self.is_connected():
            return self.rtde_r.getActualTCPPose()  # ✅ Corrigido
        return None

    # ... (restante da classe permanece igual)

    def emergency_stop(self):
        """Parada de emergência"""
        if self.rtde_c:
            self.rtde_c.stopScript()
            print("PARADA DE EMERGÊNCIA ATIVADA!")

    def set_speed_parameters(self, speed, acceleration):
        """Ajusta parâmetros de velocidade e aceleração"""
        self.speed = max(0.01, min(speed, 0.25))  # Limita entre 0.01 e 0.25
        self.acceleration = max(0.01, min(acceleration, 0.25))
        print(f"Parâmetros atualizados - Velocidade: {self.speed}, Aceleração: {self.acceleration}")
    def calcular_distancia_flange_antebraco(self, pose_alvo):
        """
        Calcula a distância entre o flange (pose alvo) e o antebraço (usando getActualToolPose).
        """
        try:
            if not self.rtde_r:
                raise RuntimeError("Interface de leitura não está disponível")

            pose_atual = self.rtde_r.getActualToolPose()
            if not pose_atual:
                raise ValueError("Não foi possível obter a pose atual do robô")

            dx = pose_alvo[0] - pose_atual[0]
            dy = pose_alvo[1] - pose_atual[1]
            dz = pose_alvo[2] - pose_atual[2]
            distancia = (dx ** 2 + dy ** 2 + dz ** 2) ** 0.5
            return distancia
        except Exception as e:
            self.last_error = f"Erro ao calcular distância flange-antebraço: {str(e)}"
            return float('inf')  # Retorna infinito em caso de erro para bloquear movimento
    
    def move_home(self, pose_home):
        print(f"[LOG] move_home chamado com pose: {pose_home}")
        return self.move_to_pose(pose_home)

    def disconnect(self):
        if self.rtde_c:
            # RTDEControlInterface não possui método desconectar explícito, 
            # mas se tivesse, você chamaria aqui.
            # Como alternativa, você pode "parar" o script ou fechar conexões se aplicável.
            try:
                self.rtde_c.stopScript()
                print("Script RTDE parado com sucesso.")
            except Exception as e:
                print(f"Erro ao parar script RTDE: {e}")
        else:
            print("Interface RTDEControl não está inicializada.")

    def stop(self):
        """Método stop que estava faltando"""
        try:
            self.em_movimento = False
            print("🛑 Robô parado com sucesso")
            return True
        except Exception as e:
            print(f"❌ Erro ao parar robô: {e}")
            return False

    def executar_movimento_peca(self, origem, destino, altura_segura, altura_pegar):
        print(f"[LOG] executar_movimento_peca chamada com:")
        print(f"       origem: {origem}")
        print(f"       destino: {destino}")
        print(f"       altura_segura: {altura_segura}")
        print(f"       altura_pegar: {altura_pegar}")

        # Aqui faça o mesmo para cada comando RTDE chamado, imprimindo as poses exatas
    def move_to_pose(self, pose):
        print(f"[LOG] move_to_pose chamado com pose: {pose}")
        if self.is_connected():
            success = self.rtde_c.moveL(pose, self.speed, self.acceleration)
            if success:
                print("[LOG] Robô movido com sucesso para a pose desejada.")
                return True
            else:
                print("[LOG] Falha ao mover para a pose desejada.")
                return False
        else:
            print("[LOG] Robô não está conectado.")
            return False
