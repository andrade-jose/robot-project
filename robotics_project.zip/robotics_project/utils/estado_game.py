 """GameService com correções para os problemas identificados"""
    
    def __init__(self, jogo=None, ia=None):
        from logic.tapatan_logic import TabuleiraTapatan
        from logic.tapatan_ai import TapatanAI
        
        self.jogo = jogo if jogo is not None else TabuleiraTapatan()
        self.ia = ia if ia is not None else TapatanAI(self.jogo)
        self.historico_movimentos = []
        
    def obter_movimento_ia(self, profundidade: int = 3) -> tuple | None:
        """Obtém movimento da IA com tratamento de erros melhorado"""
        try:
            if self.jogo.jogo_terminado():
                print("⚠️ Jogo já terminado, sem movimentos disponíveis")
                return None
            
            # Verificar se é o turno da IA (JOGADOR1)
            if self.jogo.jogador_atual != Jogador.JOGADOR1:
                print(f"⚠️ Não é o turno da IA. Turno atual: {self.jogo.jogador_atual.name}")
                return None
            
            # Obter movimento baseado na fase
            movimento = None
            
            if self.jogo.fase == FaseJogo.COLOCACAO:
                movimento = self._obter_movimento_colocacao()
            elif self.jogo.fase == FaseJogo.MOVIMENTO:
                if hasattr(self.ia, 'fazer_jogada_robo_minimax'):
                    movimento = self.ia.fazer_jogada_robo_minimax(profundidade)
                else:
                    print("❌ Método fazer_jogada_robo_minimax não encontrado na IA")
                    return None
            else:
                print(f"❌ Fase de jogo inválida: {self.jogo.fase}")
                return None
            
            if movimento is not None:
                print(f"✅ IA escolheu movimento: {movimento}")
                return movimento
            else:
                print("⚠️ IA não encontrou movimento válido")
                return None
                
        except AttributeError as e:
            print(f"❌ Erro de atributo ao obter movimento da IA: {e}")
            return None
        except Exception as e:
            print(f"❌ Erro inesperado ao obter movimento da IA: {e}")
            return None
    
    def _obter_movimento_colocacao(self) -> tuple | None:
        """Estratégia para fase de colocação com validação"""
        try:
            posicoes_vazias = self.jogo.obter_posicoes_vazias()
            if not posicoes_vazias:
                print("❌ Não há posições vazias para colocação")
                return None
            
            # Verificar se ainda pode colocar peças
            if self.jogo.pecas_colocadas.get(Jogador.JOGADOR1, 0) >= 3:
                print("❌ IA já colocou todas as 3 peças")
                return None
            
            # Priorizar centro, depois cantos, depois arestas
            posicoes_priorizadas = [4, 0, 2, 6, 8, 1, 3, 5, 7]
            
            for pos in posicoes_priorizadas:
                if pos in posicoes_vazias:
                    return (pos, pos)  # Para colocação, origem = destino
            
            return (posicoes_vazias[0], posicoes_vazias[0])
            
        except Exception as e:
            print(f"❌ Erro ao obter movimento de colocação: {e}")
            return None
    
    def atualizar_estado(self, estado_tabuleiro: list) -> dict:
        """Atualiza estado com validação melhorada"""
        try:
            if len(estado_tabuleiro) != 9:
                raise ValueError("Estado do tabuleiro deve ter 9 posições")

            # Converter lista para Jogador enums de forma segura
            self.jogo.tabuleiro = [
                Jogador.from_value(val) for val in estado_tabuleiro
            ]

            # Atualizar fase do jogo
            self._atualizar_fase_jogo()

            vencedor = self.jogo.verificar_vencedor()
            jogo_terminado = self.jogo.jogo_terminado()

            resultado = {
                'estado_tabuleiro': [pos.value for pos in self.jogo.tabuleiro],
                'fase': self.jogo.fase.value,
                'jogador_atual': self.jogo.jogador_atual.name,
                'movimentos_validos': self.jogo.obter_movimentos_validos(),
                'vencedor': vencedor.name if vencedor else None,
                'jogo_terminado': jogo_terminado,
                'num_pecas_jogador1': sum(1 for p in self.jogo.tabuleiro if p == Jogador.JOGADOR1),
                'num_pecas_jogador2': sum(1 for p in self.jogo.tabuleiro if p == Jogador.JOGADOR2)
            }

            return resultado
            
        except Exception as e:
            print(f"❌ Erro ao atualizar estado: {e}")
            return {
                'erro': str(e),
                'estado_tabuleiro': [0] * 9,
                'fase': 'colocacao',
                'jogador_atual': 'JOGADOR1',
                'jogo_terminado': False
            }
    
    def _atualizar_fase_jogo(self):
        """Atualiza a fase do jogo baseada no estado atual"""
        try:
            pecas_j1 = sum(1 for p in self.jogo.tabuleiro if p == Jogador.JOGADOR1)
            pecas_j2 = sum(1 for p in self.jogo.tabuleiro if p == Jogador.JOGADOR2)
            
            # Atualizar contadores
            self.jogo.pecas_colocadas[Jogador.JOGADOR1] = pecas_j1
            self.jogo.pecas_colocadas[Jogador.JOGADOR2] = pecas_j2
            
            # Determinar fase
            if pecas_j1 == 3 and pecas_j2 == 3:
                self.jogo.fase = FaseJogo.MOVIMENTO
            elif pecas_j1 < 3 or pecas_j2 < 3:
                self.jogo.fase = FaseJogo.COLOCACAO
            
            # Verificar se jogo terminou
            if self.jogo.verificar_vencedor():
                self.jogo.fase = FaseJogo.JOGO_TERMINADO
            elif self.jogo.fase == FaseJogo.MOVIMENTO and not self.jogo.obter_movimentos_validos():
                self.jogo.fase = FaseJogo.JOGO_TERMINADO
                
        except Exception as e:
            print(f"❌ Erro ao atualizar fase do jogo: {e}")