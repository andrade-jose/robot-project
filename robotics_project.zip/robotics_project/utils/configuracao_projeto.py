"""
Utilitário para configuração de caminhos do projeto
Elimina código duplicado em múltiplos arquivos
"""
from pathlib import Path
import sys

def configurar_caminho_projeto():
    """Configura o caminho do projeto uma única vez"""
    current_dir = Path(__file__).resolve().parent.parent
    project_root = current_dir.parent
    
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))
    
    return project_root

# Configurar automaticamente ao importar
configurar_caminho_projeto()